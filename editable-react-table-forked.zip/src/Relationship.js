import React from "react";
import { grey } from "./colors";

export default function Relationship({ value, backgroundColor }) {
  // updating margin and other style points here for cleaner display
  return (
    <span
      style={{
        boxSizing: "border-box",
        backgroundColor: backgroundColor,
        color: grey(800),
        fontWeight: 400,
        padding: "2px 6px",
        margin: "2px 2px",
        borderRadius: 4,
        textTransform: "capitalize",
        display: "flex"
      }}
    >
      {value}
    </span>
  );
}
